# idendrogram-streamlit-component

A D3-powered bi-directional Streamlit component for idendrogram library that visualizes dendrograms created by hierarchical clustering algorithms (SciPy, scikit-learn and hdbscan compatible).

Demo [TBD]

Docs @ [xxx]

## Customizing the component